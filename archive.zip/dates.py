from datetime import date
from datetime import time
from datetime import datetime


# today = date.today()

# print(today)

# print(today.day, today.month, today.year)

#get today's number
# print("todays weekday number is ", today.weekday())

#get todays date
# days =['mon', 'tues', 'weds', 'thurs', 'fri', 'sat']
# print('Which is a: ', days[today.weekday()])

#get date and time
# today = datetime.now()
# print(today)

# get just time
# t = datetime.time(datetime.now())
# print(t)