from datetime import datetime

now = datetime.now()
# print(now.strftime('%Y'))

print(now.strftime('%c'))
print(now.strftime('%x'))
print(now.strftime('%X'))
