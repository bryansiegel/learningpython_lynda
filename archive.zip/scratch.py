if(19.9 % 400):
    print('yes')