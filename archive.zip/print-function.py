if __name__ == '__main__':
    n = int(input())

# for i in range(n)[:3]:
#     print(i)
# print(n)

for i in range(1,n):
    print(i)
print(n)


