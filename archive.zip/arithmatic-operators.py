if __name__ == '__main__':
    a = int(input())

# while a < 20:
# for a in range(0,20):
#     print(a)

# while a % 2 != 0 and a <= 20:
#     print(a)
#     a += 2

for i in range(0,a):
    print(i*i)

