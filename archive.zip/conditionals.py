def main():
    x,y = 10, 100

    if(x < y):
        st = "x is less than y"

    print(st)

if __name__ == "__main__":
    main()